
## MASDEX (MARITIME SURVEILLIANCE DATA EXCHANGE)

Sistem Pertukaran Data Lalulintas Pelayaran untuk kepentingan Keselamatan Pelayaran, Kelancaran Lalulintas Pelayaran, Perlindungan Lingkungan Maritim, Keamanan Pelayaran, dan berbagai kepentingan terkait lainnya (VTS Allied Services) yang dikelola dan diselenggarakan oleh Stasiun Vessel Traffic Services dan Stasiun Radio Pantai dengan memanfaatkan data dan informasi yang dihasilkan oleh Sensor VTS, Telekomunikasi Pelayaran,  serta komunikasi dan koordinasi dengan pihak-pihak terkait

- Update progress prengerjaan melalui (https://docs.google.com/spreadsheets/d/1MEKPaqjrC2HXVo327C-bTOfnaykzHNAK/edit#gid=202540850)

## SUB MASDEX

1. INSAF (INFORMATION AND SAFETY) | PIC = Tedy (On progress)
2. SYBILL (SYSTEM BILLING) | PIC = Faris (Hold)
3. MARLENS (MARITIME LENS)  | PIC = Syerif (Hold)
4. ATONREP (AID TO NAVIGATION REPORT)  | PIC = Gian (Hold)


## TECHSTACK
1. NodeJS
2. Postgress
3. Laravel 8
4. Tailwindcss 2

## TEAMS

BUSSINES ANALYST :
- Herri
##
UI/UX :
- Faisal
- Alfian
##
PROGRAMMER :
- Syerif
- Faris
- Gian
- Tedy
##
DATABSE ANALYST :
- Herri & Full Team Porgrammer
## 
TESTER (QA) :
- Herri
